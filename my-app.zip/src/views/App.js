import React from 'react';
import { Router, Route } from 'react-router';
import Login from "./login";

console.log(Router)

function App() {
    return (
        <Router>
            <Route path="/login" component={Login} exact></Route>
        </Router>
    )
}

export default App;
