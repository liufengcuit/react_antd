import React from 'react';
import { Router, Route, Link } from 'react-router';
import { Menu, Icon } from 'antd';
import routeMenu from '../menu/index';

import './main.scss';


const { SubMenu } = Menu;

class Main extends React.Component {
    constructor(props) {
        super(props);
    }

    handleClick = e => {
        console.log('click ', e);
    };

    render(h) {
        return (
            <div className="main-container">
                <Menu
                    onClick={this.handleClick}
                    style={{ width: 256 }}
                    defaultSelectedKeys={['1']}
                    defaultOpenKeys={['sub1']}
                    mode="inline"
                >
                    <SubMenu
                        key="sub1"
                        title={
                            <span>
                            <Icon type="mail" />
                            <span>Navigation One</span>
                            </span>
                        }
                    ></SubMenu>
                </Menu>
            </div>
        )
    }
}

export default Main;